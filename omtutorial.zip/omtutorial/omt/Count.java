/*
 * $Id: OntologyModifier.java 1655 2011-12-09 15:15:45Z euzenat $
 *
 * Copyright (C) 2011, INRIA
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA.
 */

package omt;

import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.RDFWriter;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.Individual;
import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.OntProperty;
import com.hp.hpl.jena.ontology.OntModelSpec;

import java.util.Properties;
import java.util.Iterator;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;


import fr.inrialpes.exmo.align.gen.TestGenerator;
import fr.inrialpes.exmo.align.gen.BenchmarkGenerator;
import fr.inrialpes.exmo.align.gen.ParametersIds;

import fr.inrialpes.exmo.align.util.NullStream;

public class Count {

    public static void main(String[] args) {

	if ( args.length > 0 ) {
	    printAnalysis( new File( args[0] ) );
	} else {
	    File [] subdir = (new File("ontologies")).listFiles();
	    int size = subdir.length;
	    // For all ontologies
	    for ( int j=0 ; j < size; j++ ) {
		printAnalysis( subdir[j] );
	    }
	}
    }

    public static void printAnalysis( File file ) {
	try {
	    //if( subdir[j].isDirectory() ) {
	    System.out.println( " *** "+file );
	    System.err.println( " *** "+file );
	    // Times loading
	    long time = System.currentTimeMillis();
	    OntModel ont = loadOntology( file );
	    long newTime = System.currentTimeMillis();
	    long timetoload = newTime - time;
	    System.out.println( "Time to load: "+timetoload );
	    String namespace = ont.getNsPrefixURI("");
	    System.out.println( namespace );
	    // count classes and properties
	    int nblocclass = 0;
	    int nbclass = 0;
	    for ( Iterator it = ont.listNamedClasses(); it.hasNext(); ) {
		OntClass aux = (OntClass)it.next();
		nbclass++;
		if ( aux.getNameSpace().equals( namespace ) ) {
		    nblocclass++;
		}
	    }
	    //System.err.println("Classes: "+nbclass);
	    int nbprop = 0;
	    int nblocprop = 0;
	    for ( Iterator it = ont.listAllOntProperties(); it.hasNext(); ) {
		OntProperty prop = (OntProperty)it.next();
		nbprop++;
		if ( prop.getNameSpace().equals( namespace ) )
		    nblocprop++;
	    }
	    //System.err.println("Properties: "+nbprop);
	    int nbind = 0;
	    for ( Iterator it = ont.listIndividuals(); it.hasNext(); ) {
		Individual ind = (Individual)it.next();
		//if ( ind.getNameSpace().equals( namespace ) )
		nbind++;
	    }
	    System.out.println( "Classes: "+nbclass+" ("+nblocclass+") / Properties: "+nbprop+" ("+nblocprop+") / Instances: "+nbind );
	    System.err.println( "Classes: "+nbclass+" ("+nblocclass+") / Properties: "+nbprop+" ("+nblocprop+") / Instances: "+nbind );
	    // count triples
	    int nbtriples = 0;
	    for ( Statement st : ont.listStatements().toList() ) nbtriples++;
	    // Time printing
	    // Report
	    System.out.println( "Total entities: "+(nbclass+nbprop+nbind)+" ("+(nblocclass+nblocprop+nbind)+") / Total triples: "+nbtriples );
	    time = System.currentTimeMillis();
	    writeOntology( ont, namespace );
	    newTime = System.currentTimeMillis();
	    long timetowrite = newTime - time;
	    System.out.println( "Time to write: "+timetowrite );
	    System.out.println();
	    //writeOntology2( ont, ont.getNsPrefixURI("") );
	    //writeOntology2( ont, "http://toti.org" );
	} catch (Exception ex) { ex.printStackTrace(); }
    }

    public static OntModel loadOntology( File file ) {
	OntModel model = ModelFactory.createOntologyModel( OntModelSpec.OWL_MEM, null );
	model.read( file.toURI().toString() );
	return model;
    }

    public static void writeOntology( OntModel model, String ns ) {
        try {
            OutputStream fout = new NullStream();
            Charset defaultCharset = Charset.forName("UTF8");
            RDFWriter writer = model.getWriter("RDF/XML-ABBREV");
            writer.setProperty( "showXmlDeclaration","true" );
            model.setNsPrefix( "", ns );
            writer.setProperty( "xmlbase", ns );
            model.createOntology( ns );
            writer.write( model.getBaseModel(), new OutputStreamWriter(fout, defaultCharset), "");
            fout.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void writeOntology2( OntModel model, String ns ) {//model.getBaseModel()
        try {
            Charset defaultCharset = Charset.forName("UTF8");
            RDFWriter writer = model.getWriter("RDF/XML-ABBREV");
            writer.setProperty( "showXmlDeclaration","true" );
            model.setNsPrefix( "", ns );
            writer.setProperty( "xmlbase", ns );
            //model.createOntology( ns );
            writer.write( model.getBaseModel(), new OutputStreamWriter( System.out, defaultCharset), "");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
