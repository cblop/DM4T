/*
 * $Id: TestConsistency.java 1894 2014-03-10 14:28:40Z euzenat $
 *
 * Copyright (C) INRIA, 2009-2010, 2013-2014
 *
 * Modifications to the initial code base are copyright of their
 * respective authors, or their employers as appropriate.  Authorship
 * of the modifications may be determined from the ChangeLog placed at
 * the end of this file.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA.
 */

package omt;

// Alignment API classes
import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.AlignmentException;
import org.semanticweb.owl.align.AlignmentVisitor;

// Alignment API implementation classes
import fr.inrialpes.exmo.align.impl.renderer.OWLAxiomsRendererVisitor;
import fr.inrialpes.exmo.align.parser.AlignmentParser;

// OWL API
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.reasoner.OWLReasoner;

// HermiT
import org.semanticweb.HermiT.Reasoner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Java standard classes
import java.util.Properties;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.io.File;
import java.io.FileWriter;
import java.net.URI;
import java.net.URISyntaxException;

/**
 * TestConsistency
 *
 * Test the consistency of an alignment
 */

public class TestSubsumption {
    final static Logger logger = LoggerFactory.getLogger( TestSubsumption.class );

    public static void main( String[] args ) {
	try {
	    new TestSubsumption().run( args );
	} catch ( Exception ex ) {
	    ex.printStackTrace();
	}
    }

    public void run( String[] args ) {
	if ( args.length < 3 ) {
	    System.err.println("Arguments required: alignment URI + two class URIs");
	    return;
	}
	String initName = args[0];
	String myId = "Test";
	Alignment al = null;
	URI uri1 = null;
	URI uri2 = null;
	String u1 = "file:ontology1.owl";
	String u2 = "file:ontology2.owl";
	Properties params = new Properties();
	try {
	    uri1 = new URI( u1 );
	    uri2 = new URI( u2 );
	} catch (URISyntaxException use) { use.printStackTrace(); }

	// Load an alignment
	try {
	    AlignmentParser aparser = new AlignmentParser();
	    al = aparser.parse( initName );
	} catch ( AlignmentException alex ) { alex.printStackTrace(); }
	logger.debug(" Alignment structure parsed");

	// Generate a merged ontology between the ontologies (OWLAxioms)
	PrintWriter writer = null;
	File merged = null;
	try {
	    merged = new File( "mmmmm.owl" );
	    //merged = File.createTempFile( "MyApp-results",".owl");
	    //merged.deleteOnExit();
	    writer = new PrintWriter ( new FileWriter( merged, false ), true );
	    AlignmentVisitor renderer = new OWLAxiomsRendererVisitor(writer);
	    al.render(renderer);
	} catch (UnsupportedEncodingException uee) {
	    uee.printStackTrace();
	} catch (AlignmentException ae) {
	    ae.printStackTrace();
	} catch (IOException ioe) { 
	    ioe.printStackTrace();
	} finally {
	    if ( writer != null ) {
		writer.flush();
		writer.close();
	    }
	}

	// Use the OWLReasoner to answer queries (at the ontology level)
	OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
	OWLReasoner reasoner = null;

	// Load the generated ontology 
	try {
	    OWLOntology ontology = manager.loadOntology( IRI.create( "file:"+merged.getPath() ) );
	    reasoner = new Reasoner( ontology );
	} catch (OWLOntologyCreationException ooce) {
	    ooce.printStackTrace(); 
	}

	// Test consistency
	if ( reasoner.isConsistent() ) {
	    System.err.println( "The aligned ontologies are consistent" );
	} else {
	    System.err.println( "The aligned ontologies are inconsistent" );
	}

	OWLClass cl1 = manager.getOWLDataFactory().getOWLClass( IRI.create( args[1] ) );   
	OWLClass cl2 = manager.getOWLDataFactory().getOWLClass( IRI.create( args[2] ) );
	testOWLReasonerSubClass( manager, reasoner, cl1, cl2 );
	testOWLReasonerSubClass( manager, reasoner, cl2, cl1 );
	// DISJOINTNESS TEST would be nice
    }

    private String clname( OWLClassExpression cl ) {
	return cl.asOWLClass().getIRI().getFragment();
    }

    public void testOWLReasonerSubClass( OWLOntologyManager manager, OWLReasoner reasoner, OWLClassExpression d1, OWLClassExpression d2 ) {
	OWLAxiom axiom = manager.getOWLDataFactory().getOWLSubClassOfAxiom( d1, d2 );
	if ( reasoner.isEntailed( axiom ) ) {
	    System.out.println( "OWLReasoner(Merged): "+clname(d1)+" is subclass of "+clname(d2) );
	} else {
	    System.out.println( "OWLReasoner(Merged): "+clname(d1)+" is not necessarily subclass of "+clname(d2) );
	}
    }

}
