Copyright 2012 by the Department of Computer Science (University of Oxford)

LogMap is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

LogMap is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along with LogMap.  If not, see <http://www.gnu.org/licenses/>.



LogMap is a highly scalable ontology matching system with ‘built-in’ reasoning and inconsistency repair capabilities. To the best of our knowledge, LogMap is the only matching system that (1) can efficiently match semantically rich ontologies containing tens (and even hundreds) of thousands of classes, (2)incorporates sophisticated reasoning and repair techniques to minimise the number of logical inconsistencies, and (3) provides support for user intervention during the matching process (this functionality is not provided in this standalone distribution of LogMap).

LogMap integrates the OWL API and HermiT reasoner which are also under the LGPL license.


REQUIREMENTS:

Java 1.6 or higher.

The main LogMap's dependencies are the OWL API and the HermiT 1.3.6, which already bundles the OWL API (see http://www.cs.ox.ac.uk/isg/tools/HermiT//download/1.3.6/).

Additionally, LogMap source codes also depend on other libraries, although they are not necessary for the "matching" and "repair" functionalities:

1. LogMap's web facility uses JavaMail API: http://www.oracle.com/technetwork/java/javamail/index.html

2. Additional OWL 2 reasoners that can be used instead of HermiT (see `uk.ac.ox.krr.logmap2.reasoning.ReasonerManager`):
   - Pellet reasoner (http://clarkparsia.com/pellet/)
   - ELK reasoner (http://code.google.com/p/elk-reasoner/)
   - FaCT++ reasoner (http://owl.man.ac.uk/factplusplus/)
   - TrOWL reasoner (http://trowl.eu/)

USAGE:

LogMap2_Matcher.java and LogMap2_RepairFacility.java are the main classes.


