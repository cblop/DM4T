/*******************************************************************************
 * Copyright 2012 by the Department of Computer Science (University of Oxford)
 * 
 *    This file is part of LogMap.
 * 
 *    LogMap is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU Lesser General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 * 
 *    LogMap is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Lesser General Public License for more details.
 * 
 *    You should have received a copy of the GNU Lesser General Public License
 *    along with LogMap.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/
package uk.ac.ox.krr.logmap2.oaei;

import java.io.File;
import java.net.URI;

import java.util.ArrayList;
import java.util.List;
import java.util.HashSet;
import java.util.Set;


import uk.ac.manchester.cs.owl.OWLUntypedConstantImpl; 


import org.semanticweb.owl.model.OWLConstant;
import org.semanticweb.owl.apibinding.OWLManager;
import org.semanticweb.owl.model.AddAxiom;
import org.semanticweb.owl.model.OWLAxiom;
import org.semanticweb.owl.model.OWLDeclarationAxiom;
import org.semanticweb.owl.model.OWLObjectPropertyAssertionAxiom;
import org.semanticweb.owl.model.OWLObjectPropertyExpression;
import org.semanticweb.owl.model.OWLDataPropertyAssertionAxiom;
import org.semanticweb.owl.model.OWLDataPropertyExpression;
import org.semanticweb.owl.model.OWLIndividual;
import org.semanticweb.owl.model.OWLDataProperty;
import org.semanticweb.owl.model.OWLObjectProperty;
import org.semanticweb.owl.model.OWLEntity;
import org.semanticweb.owl.model.OWLIndividualAxiom;

import org.semanticweb.owl.model.OWLDataFactory;
import org.semanticweb.owl.model.OWLOntology;

import org.semanticweb.owl.model.OWLOntologyChange;
import org.semanticweb.owl.model.OWLOntologyManager;
import org.semanticweb.owl.io.RDFXMLOntologyFormat;

import uk.ac.ox.krr.logmap2.io.WriteFile;
import uk.ac.ox.krr.logmap2.utilities.Utilities;


/**
 * Note this class is based on the old OWL API to load the OAEI RDF-Alignment 
 * (with new OWL API does not work since mappings retrived as anonymous individuals).
 * In the current FromRDFAlign2OWL an XML reader is used instead
 * @deprecated
 * @author Ernesto
 *
 */
public class FromRDFAlign2OWL_old_api {
	
	//private String uriStr = "http://knowledgeweb.semanticweb.org/heterogeneity/";
	
	//used in gold
	private String align1_prop="alignmententity1";
	private String align2_prop="alignmententity2";
	
	//Used in aroma
	private String align1_prop_2="entity1";
	private String align2_prop_2="entity2";
	
	//Used in gokld standards
	private String type_align="alignmentrelation";
	private String measure_align="alignmentmeasure";
	
	//used in aroma
	private String type_align_2="relation";
	private String measure_align_2="measure";
	
	
	private OWLOntologyManager ontology1Manager;
	private OWLOntologyManager ontology2Manager;	
	private OWLOntologyManager goldStandardManager;
	
	private OWLOntologyManager goldStandardManager_out;
		
	private OWLOntology ontology1;
	private OWLOntology ontology2;
	private OWLOntology goldStandard;
	private OWLOntology goldStandard_out;
	
	
	//Anatomy
	//static String irirootpath = "file:/home/ernesto/EclipseWS/DataUMLS/UMLS_Onto_Versions/Anatomy/";
	//static String rootpath = "/home/ernesto/EclipseWS/DataUMLS/UMLS_Onto_Versions/Anatomy/";
	
	//static String irirootpath = "file:/C:/Users/ernesto/ontologies/OM/";
	//static String rootpath = "C:/Users/ernesto/ontologies/OM/";
		
	
		
	String mappingURI="http://krr.ox.ac.uk/ontologies/mapping.owl";
	
	
	
	OWLDataFactory datafactory;
	
	
	Set<OWLAxiom> axiomGS = new HashSet<OWLAxiom>();
	
	List<OWLOntologyChange> changes;
	
	WriteFile writer;
	
	
	
	
	public FromRDFAlign2OWL_old_api(String onto1, String onto2, String GS_in, String GS_out, String GS_out_txt) throws Exception{
		this(onto1, onto2, GS_in, GS_out, GS_out_txt, false);
	}
	
	public FromRDFAlign2OWL_old_api(String onto1, String onto2, String GS_in, String GS_out, String GS_out_txt, boolean individualsGS) throws Exception{
		
		changes = new ArrayList<OWLOntologyChange>();
		
		if (!individualsGS){ //no need for indiv, only indiv are matched
			loadOntology1(onto1);
			loadOntology2(onto2);
		}
		
		
		loadGoldStandard(GS_in);
		
		datafactory=goldStandardManager.getOWLDataFactory();
		
		writer = new WriteFile(GS_out_txt);
		
		//writer.writeLine("Hola");
		
		if (individualsGS){
			trasformGS2OWL_Only4Individuals(mappingURI,  GS_out);
		}
		else{
			trasformGS2OWL(mappingURI,  GS_out);
		}
		
		
		
		writer.closeBuffer();
		
		//createGoldStandardOut(mappingURI,  GS_out);
		
		
		
	}
	
	
	
	public FromRDFAlign2OWL_old_api(OWLOntology onto1, OWLOntology onto2, String GS_in, String GS_out, String GS_out_txt, boolean individualsGS) throws Exception{
		
		changes = new ArrayList<OWLOntologyChange>();

		this.ontology1 = onto1;
		this.ontology2 = onto2;

		
		
		loadGoldStandard(GS_in);
		
		datafactory=goldStandardManager.getOWLDataFactory();
		
		writer = new WriteFile(GS_out_txt);
		
		//writer.writeLine("Hola");
		
		if (individualsGS){
			trasformGS2OWL_Only4Individuals(mappingURI,  GS_out);
		}
		else{
			trasformGS2OWL(mappingURI,  GS_out);
		}
		
		
		
		writer.closeBuffer();
		
		//createGoldStandardOut(mappingURI,  GS_out);
		
		
		
	}
	
	
	
	public void trasformGS2OWL(String uriStr, String phisycalUriStr) throws Exception{
		
		goldStandardManager_out = OWLManager.createOWLOntologyManager();		
		goldStandard_out=goldStandardManager_out.createOntology(URI.create(uriStr));
		
		
		OWLEntity ent=null;
		
		OWLAxiom ax=null;
		//OWLAxiom ax1=null;
		//OWLAxiom ax2=null;
		OWLEntity ent1=null;
		OWLEntity ent2=null;
		String relation="";
		String measure="";
		
		//changes.add(new AddAxiom(goldStandard_out, datafactory.getowlde));
		
		String uriMeasure = mappingURI + "#measure";
		OWLConstant confidenceLiteral; 

		
		Set<OWLDataPropertyExpression> dataPSet = new HashSet<OWLDataPropertyExpression>();
		Set<OWLObjectPropertyExpression> objPSet = new HashSet<OWLObjectPropertyExpression>();
		
		
		
		//Each individaul will be a map or a resourece (class, property)
		for (OWLIndividual ind : goldStandard.getReferencedIndividuals()){
			
			ent1=null;
			ent2=null;
			
			//System.out.println("Indiv: " + ind );
			
			if (ontology1.containsClassReference(ind.getURI())
					|| ontology2.containsClassReference(ind.getURI())){
				
				ent=datafactory.getOWLClass(ind.getURI());
				//System.out.println("C1: " + ent);
				changes.add(new AddAxiom(goldStandard_out, datafactory.getOWLDeclarationAxiom(ent)));
			}
			else if (ontology1.containsObjectPropertyReference(ind.getURI()) ||
					ontology2.containsObjectPropertyReference(ind.getURI())){
				
				ent=datafactory.getOWLObjectProperty(ind.getURI());
				//System.out.println("OP1: " + ent);
				changes.add(new AddAxiom(goldStandard_out, datafactory.getOWLDeclarationAxiom(ent)));
			}
			
			else if (ontology1.containsDataPropertyReference(ind.getURI())
					|| ontology2.containsDataPropertyReference(ind.getURI())){
				
				ent=datafactory.getOWLDataProperty(ind.getURI());
				//System.out.println("DP1: " + ent);
				changes.add(new AddAxiom(goldStandard_out, datafactory.getOWLDeclarationAxiom(ent)));
			}
			
			
					
			
			
			else{
			
				for (OWLObjectPropertyAssertionAxiom oAx : goldStandard.getObjectPropertyAssertionAxioms(ind)){
					if (align1_prop.equals(oAx.getProperty().toString()) || align1_prop_2.equals(oAx.getProperty().toString())){
						
						if (ontology1.containsClassReference(oAx.getObject().getURI())){
							ent1=datafactory.getOWLClass(oAx.getObject().getURI());
							//System.out.println("Class1: " + ent1);
						}
						else if (ontology1.containsObjectPropertyReference(oAx.getObject().getURI())){
							ent1=datafactory.getOWLObjectProperty(oAx.getObject().getURI());
							//System.out.println("OProp1: " + ent1);
						}
						
						else if (ontology1.containsDataPropertyReference(oAx.getObject().getURI())){
							ent1=datafactory.getOWLDataProperty(oAx.getObject().getURI());
							//System.out.println("DProp1: " + ent1);
						}
						else{
							System.out.println("Not correspondence 1: " + oAx.getObject().getURI());
							continue;
						}
					}
					else if (align2_prop.equals(oAx.getProperty().toString()) || align2_prop_2.equals(oAx.getProperty().toString())){
						if (ontology2.containsClassReference(oAx.getObject().getURI())){
							ent2=datafactory.getOWLClass(oAx.getObject().getURI());
							//System.out.println("Class2: " + ent2);
						}
						else if (ontology2.containsObjectPropertyReference(oAx.getObject().getURI())){
							ent2=datafactory.getOWLObjectProperty(oAx.getObject().getURI());
							//System.out.println("OProp2: " + ent2);
						}
						
						else if (ontology2.containsDataPropertyReference(oAx.getObject().getURI())){
							ent2=datafactory.getOWLDataProperty(oAx.getObject().getURI());
							//System.out.println("DProp2: " + ent2);
						}
						else{
							System.out.println("Not correspondence 2: " + oAx.getObject().getURI());
							continue;
						}
					}
					
					//System.out.println("OAx: " + oAx);
					//System.out.println(oAx.getProperty() +  " " + oAx.getProperty().asOWLObjectProperty().getURI());
				}
			
			
				for (OWLDataPropertyAssertionAxiom dAx : goldStandard.getDataPropertyAssertionAxioms(ind)){
					if (measure_align.equals(dAx.getProperty().toString()) || measure_align_2.equals(dAx.getProperty().toString())){
						measure = dAx.getObject().getLiteral();
						//System.out.println("Measure: " + measure);
					}
					else if (type_align.equals(dAx.getProperty().toString()) || type_align_2.equals(dAx.getProperty().toString())){
						relation = dAx.getObject().getLiteral();
						//System.out.println("Relation: " + relation);
					}
					//System.out.println("DAx: " + dAx);
				}
				
				if (ent1==null || ent2==null)
					continue;
				
				ax=null;
				dataPSet.clear();
				objPSet.clear();
				
				//System.out.println("rel" + relation);
				
				if (relation.equals("=") || relation.contains("EquivRelation") || relation.contains("BasicRelation")){
					if (ent1.isOWLClass() && ent2.isOWLClass()){
						
						confidenceLiteral = new OWLUntypedConstantImpl(datafactory, measure, null);
						
						ax=datafactory.getOWLEquivalentClassesAxiom(ent1.asOWLClass(), ent2.asOWLClass());						
						//ax1=datafactory.getOWLSubClassAxiom(ent1.asOWLClass(), ent2.asOWLClass());
						//ax2=datafactory.getOWLSubClassAxiom(ent2.asOWLClass(), ent1.asOWLClass());
						
						//System.out.println(ax);
						
						changes.add(new AddAxiom(goldStandard_out, ax));
						//TODO  Revise the way of addion annotations!					
						//changes.add(new AddAxiom(goldStandard_out, 
						//		datafactory.getOWLAxiomAnnotationAxiom(ax, datafactory.getOWLConstantAnnotation(
						//				URI.create(uriMeasure), confidenceLiteral))));
						
						/*changes.add(new AddAxiom(goldStandard_out, ax1));
						changes.add(new AddAxiom(goldStandard_out, 
								datafactory.getOWLAxiomAnnotationAxiom(ax1, datafactory.getOWLConstantAnnotation(
										URI.create(uriMeasure), confidenceLiteral))));
						
						changes.add(new AddAxiom(goldStandard_out, ax2));
						changes.add(new AddAxiom(goldStandard_out, 
								datafactory.getOWLAxiomAnnotationAxiom(ax2, datafactory.getOWLConstantAnnotation(
										URI.create(uriMeasure), confidenceLiteral))));
						*/
						
						writer.writeLine(ent1.getURI().toString() + "|" + ent2.getURI().toString() + "|=|" + measure);
						
						
					}
					else if (ent1.isOWLObjectProperty() && ent2.isOWLObjectProperty()){
						
						objPSet.add(ent1.asOWLObjectProperty());
						objPSet.add(ent2.asOWLObjectProperty());
						
						ax=datafactory.getOWLEquivalentObjectPropertiesAxiom(objPSet);
						//ent1.asOWLObjectProperty(), ent2.asOWLObjectProperty()
						
						confidenceLiteral = new OWLUntypedConstantImpl(datafactory, measure, null);
												
						//ax1=datafactory.getOWLSubObjectPropertyAxiom(ent1.asOWLObjectProperty(), ent2.asOWLObjectProperty());
						//ax2=datafactory.getOWLSubObjectPropertyAxiom(ent2.asOWLObjectProperty(), ent1.asOWLObjectProperty());
						
						changes.add(new AddAxiom(goldStandard_out, ax));
						
						//TODO  Revise the way of addion annotations!						//
						//changes.add(new AddAxiom(goldStandard_out, 
						//		datafactory.getOWLAxiomAnnotationAxiom(ax, datafactory.getOWLConstantAnnotation(
						//				URI.create(uriMeasure), confidenceLiteral))));
						
						/*changes.add(new AddAxiom(goldStandard_out, ax1));
						changes.add(new AddAxiom(goldStandard_out, 
								datafactory.getOWLAxiomAnnotationAxiom(ax1, datafactory.getOWLConstantAnnotation(
										URI.create(uriMeasure), confidenceLiteral))));
						
						changes.add(new AddAxiom(goldStandard_out, ax2));
						changes.add(new AddAxiom(goldStandard_out, 
								datafactory.getOWLAxiomAnnotationAxiom(ax2, datafactory.getOWLConstantAnnotation(
										URI.create(uriMeasure), confidenceLiteral))));
						*/
						
						writer.writeLine(ent1.getURI().toString() + "|" + ent2.getURI().toString() + "|=|" + measure);
						
					}
					else if (ent1.isOWLDataProperty() && ent2.isOWLDataProperty()){
						
						dataPSet.add(ent1.asOWLDataProperty());
						dataPSet.add(ent2.asOWLDataProperty());
						
						ax=datafactory.getOWLEquivalentDataPropertiesAxiom(dataPSet);
						//.getOWLEquivalentDataPropertiesAxiom(ent1.asOWLDataProperty(), ent2.asOWLDataProperty());
						
						//ax1=datafactory.getOWLSubDataPropertyAxiom(ent1.asOWLDataProperty(), ent2.asOWLDataProperty());
						//ax2=datafactory.getOWLSubDataPropertyAxiom(ent2.asOWLDataProperty(), ent1.asOWLDataProperty());
						
						changes.add(new AddAxiom(goldStandard_out, ax));
						
						//TODO  Revise the way of addion annotations!
						//confidenceLiteral = new OWLUntypedConstantImpl(datafactory, measure, null);
						//
						//changes.add(new AddAxiom(goldStandard_out, 
						//		datafactory.getOWLAxiomAnnotationAxiom(ax, datafactory.getOWLConstantAnnotation(
						//				URI.create(uriMeasure), confidenceLiteral))));
						
						/*confidenceLiteral = new OWLUntypedConstantImpl(datafactory, measure, null);
						changes.add(new AddAxiom(goldStandard_out, ax1));
						changes.add(new AddAxiom(goldStandard_out, 
								datafactory.getOWLAxiomAnnotationAxiom(ax1, datafactory.getOWLConstantAnnotation(
										URI.create(uriMeasure), confidenceLiteral))));
						
						changes.add(new AddAxiom(goldStandard_out, ax2));
						changes.add(new AddAxiom(goldStandard_out, 
								datafactory.getOWLAxiomAnnotationAxiom(ax2, datafactory.getOWLConstantAnnotation(
										URI.create(uriMeasure), confidenceLiteral))));*/
						
						writer.writeLine(ent1.getURI().toString() + "|" + ent2.getURI().toString() + "|=|" + measure);
						
					}
					else{
						System.err.println("Wrong mapping mixing entities " + ind);
						continue;
					}
					
				}
				else if (relation.equals("<")){
					if (ent1.isOWLClass() && ent2.isOWLClass()){
						ax=datafactory.getOWLSubClassAxiom(ent1.asOWLClass(), ent2.asOWLClass());
					}
					else if (ent1.isOWLObjectProperty() && ent2.isOWLObjectProperty()){
						ax=datafactory.getOWLSubObjectPropertyAxiom(ent1.asOWLObjectProperty(), ent2.asOWLObjectProperty());
					}
					else if (ent1.isOWLDataProperty() && ent2.isOWLDataProperty()){
						ax=datafactory.getOWLSubDataPropertyAxiom(ent1.asOWLDataProperty(), ent2.asOWLDataProperty());
					}
					else{
						System.err.println("Wrong mapping mixing entities " + ind);
						continue;
					}
					writer.writeLine(ent1.getURI().toString() + "|" + ent2.getURI().toString() + "|<|" + measure);
					
				}
				
				else if (relation.equals(">")){
					
					if (ent1.isOWLClass() &&  ent2.isOWLClass()){
						ax=datafactory.getOWLSubClassAxiom(ent2.asOWLClass(), ent1.asOWLClass());
					}
					else if (ent1.isOWLObjectProperty() &&  ent2.isOWLObjectProperty()){
						ax=datafactory.getOWLSubObjectPropertyAxiom(ent2.asOWLObjectProperty(), ent1.asOWLObjectProperty());
					}
					else if (ent1.isOWLDataProperty() && ent2.isOWLDataProperty()){
						ax=datafactory.getOWLSubDataPropertyAxiom(ent2.asOWLDataProperty(), ent1.asOWLDataProperty());
					}
					else{
						System.err.println("Wrong mapping mixing entities " + ind);
						continue;
					}
					
					writer.writeLine(ent1.getURI().toString() + "|" + ent2.getURI().toString() + "|>|" + measure);
					
				}
				
				if (ax!=null) { //Not for equivaleneces or incompatible cases
					
					confidenceLiteral = new OWLUntypedConstantImpl(datafactory, measure, null);
					
					changes.add(new AddAxiom(goldStandard_out, ax));
					
					//TODO  Revise the way of addion annotations!					//
					//changes.add(new AddAxiom(goldStandard_out, 
					//		datafactory.getOWLAxiomAnnotationAxiom(ax, datafactory.getOWLConstantAnnotation(
					//				URI.create(uriMeasure), confidenceLiteral))));
					
				}
				//else
				//	System.err.println("Wrong mapping mixing entities " + ind);
				
				
				
			}//end else	
		}//end for indiv
		
		
		//System.out.println(changes.size());
		
		goldStandardManager_out.applyChanges(changes);
		
		goldStandardManager_out.saveOntology(goldStandard_out, new RDFXMLOntologyFormat(), URI.create(phisycalUriStr));
		
		
		
		
		
	}
	
	
	
	
	public void trasformGS2OWL_Only4Individuals(String uriStr, String phisycalUriStr) throws Exception{
		
		goldStandardManager_out = OWLManager.createOWLOntologyManager();		
		goldStandard_out=goldStandardManager_out.createOntology(URI.create(uriStr));
		
		
		//OWLIndividual ent=null;
		
		OWLAxiom ax=null;
		//OWLAxiom ax1=null;
		//OWLAxiom ax2=null;
		OWLIndividual ent1=null;
		OWLIndividual ent2=null;
		String relation="";
		String measure="";
		
		//changes.add(new AddAxiom(goldStandard_out, datafactory.getowlde));
		
		String uriMeasure = mappingURI + "#measure";
		OWLConstant confidenceLiteral; 

		
		Set<OWLIndividual> setIndiv = new HashSet<OWLIndividual>();
	
		
		
		//Each individaul will be a map or a resourece (class, property)
		for (OWLIndividual ind : goldStandard.getReferencedIndividuals()){
			
			ent1=null;
			ent2=null;
			
			//ent = datafactory.getOWLIndividual(ind.getURI());
			//changes.add(new AddAxiom(goldStandard_out, datafactory.getOWLDeclarationAxiom(ent)));
			
			for (OWLObjectPropertyAssertionAxiom oAx : goldStandard.getObjectPropertyAssertionAxioms(ind)){
				
				if (align1_prop.equals(oAx.getProperty().toString()) || align1_prop_2.equals(oAx.getProperty().toString())){
						
					ent1=datafactory.getOWLIndividual(oAx.getObject().getURI());
						
				}
				else if (align2_prop.equals(oAx.getProperty().toString()) || align2_prop_2.equals(oAx.getProperty().toString())){

					ent2=datafactory.getOWLIndividual(oAx.getObject().getURI());
					
				}
			}
			
			for (OWLDataPropertyAssertionAxiom dAx : goldStandard.getDataPropertyAssertionAxioms(ind)){
					
				if (measure_align.equals(dAx.getProperty().toString()) || measure_align_2.equals(dAx.getProperty().toString())){
					measure = dAx.getObject().getLiteral();
						//System.out.println("Measure: " + measure);
				}
				else if (type_align.equals(dAx.getProperty().toString()) || type_align_2.equals(dAx.getProperty().toString())){
					relation = dAx.getObject().getLiteral();
						//System.out.println("Relation: " + relation);
				}
					//System.out.println("DAx: " + dAx);
			}
				
			if (ent1==null || ent2==null)
				continue;
				
			setIndiv.clear();
			setIndiv.add(ent1);
			setIndiv.add(ent2);
			
			
			ax=datafactory.getOWLSameIndividualsAxiom(setIndiv);
			confidenceLiteral = new OWLUntypedConstantImpl(datafactory, measure, null);
			
			changes.add(new AddAxiom(goldStandard_out, ax));
			changes.add(new AddAxiom(goldStandard_out, 
					datafactory.getOWLAxiomAnnotationAxiom(ax, datafactory.getOWLConstantAnnotation(
							URI.create(uriMeasure), confidenceLiteral))));
			
			writer.writeLine(ent1.getURI().toString() + "|" + ent2.getURI().toString() + "|=|" + measure);
				
		}//end for indiv
		
		
		//System.out.println(changes.size());
		
		goldStandardManager_out.applyChanges(changes);
		
		goldStandardManager_out.saveOntology(goldStandard_out, new RDFXMLOntologyFormat(), URI.create(phisycalUriStr));
		
		
		
		
		
	}
	
	
	private static String convert2ThreeDigitStrNumber(int number){
		
		String three_digits = String.valueOf(number);
		
		if (three_digits.length()==1)
			three_digits="00" + three_digits;
		else if (three_digits.length()==2)
			three_digits="0" + three_digits;
		
		return three_digits;
		
	}
	
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String irirootpath = "file:/usr/local/data/DataUMLS/UMLS_Onto_Versions/OAEI_datasets/oaei_2012/fma2nci/";
		//String irirootpath = "file:/usr/local/data/DataUMLS/UMLS_Onto_Versions/OAEI_datasets/Mappings_Tools_2012/";
		
		//String mappings_path = "/usr/local/data/DataUMLS/UMLS_Onto_Versions/OAEI_datasets/Mappings_Tools/";
		//String mappings_path = "/usr/local/data/DataUMLS/UMLS_Onto_Versions/OAEI_datasets/OutputAlcomo/";
		String mappings_path = "/usr/local/data/DataUMLS/UMLS_Onto_Versions/OAEI_datasets/Mappings_Tools_2012/";
		
		
		int max_folder=80;  //11 sandbox  //80 iimb
		//mappings_path = "/usr/local/data/Instance/sandbox/";
		//mappings_path = "/usr/local/data/Instance/iimb/";
		//mappings_path = "/usr/local/data/Instance/iimb_large/";
		
		
		String irirootpath_mappings = "file:" + mappings_path; 

		
		int onto_pair;
		//onto_pair = Utilities.FMA2NCI;
		//onto_pair = Utilities.FMA2SNOMED;
		onto_pair = Utilities.SNOMED2NCI;
		
		String onto1;
		String onto2;
		String pattern;
		if (onto_pair==Utilities.FMA2NCI){
			//FMA2NCI
			onto1 = irirootpath + "oaei2012_FMA_whole_ontology.owl";
			onto2 = irirootpath + "oaei2012_NCI_whole_ontology.owl";
			pattern="fma2nci.rdf";
		}
		else if (onto_pair==Utilities.FMA2SNOMED){
			onto1 = irirootpath + "oaei2012_FMA_whole_ontology.owl";
			onto2 = "file:/usr/local/data/DataUMLS/UMLS_Onto_Versions/OAEI_datasets/snomed20090131_replab.owl.zip";
			pattern="fma2snomed.rdf";
		}
		else{
			onto1 = "file:/usr/local/data/DataUMLS/UMLS_Onto_Versions/OAEI_datasets/snomed20090131_replab.owl.zip";
			onto2 = irirootpath + "oaei2012_NCI_whole_ontology.owl";
			pattern="snomed2nci.rdf";
		}
		
		
		
		
		String mappings_file;
		String gold_rdf;	
		String gold_owl;
		String gold_txt;
		
		try {
			
			
			if (args.length==5) {
				
				new FromRDFAlign2OWL_old_api(args[0], args[1], args[2], args[3], args[4]);
			
			}
			
			else {
				
				
				File directory = new File(mappings_path);
				String filenames[] = directory.list();
				
				
				System.out.println("Loading ontologies...");
				OWLOntology OWLonto1 = loadOntology(onto1);
				OWLOntology OWLonto2 = loadOntology(onto2); 
				System.out.println("...Done");

				for(int i=0; i<filenames.length; i++){
					//if (!filenames[i].contains("oaei2012_FMA2SNMD_repaired_UMLS_mappings_alcomo.rdf"))
					//if (!filenames[i].contains("oaei2012_FMA2NCI_repaired_UMLS_mappings_alcomo.rdf"))
					//if (!filenames[i].contains("refalign.rdf"))
					//if (!filenames[i].contains(".rdf"))
					if (!filenames[i].contains(pattern) || !(filenames[i].contains("gomma")))
						continue;
					
					System.out.println("Converting " + filenames[i] + "...");
					
					mappings_file = filenames[i].split("\\.")[0];
					
					
					gold_rdf = irirootpath_mappings + filenames[i];	
					gold_owl = irirootpath_mappings + mappings_file + ".owl";
					gold_txt = mappings_path + mappings_file + ".txt";
				
					//new FromRDFAlign2OWL(onto1, onto2, gold_rdf, gold_owl, gold_txt, false); //true for instance matching track
					new FromRDFAlign2OWL_old_api(OWLonto1, OWLonto2, gold_rdf, gold_owl, gold_txt, false); //true for instance matching track
					
					System.out.println("...Done");
					
				}
					
					
				
				/*  INSTANCE
				for (int folder=1; folder<=max_folder;folder++){//instance
				
				File directory = new File(mappings_path + convert2ThreeDigitStrNumber(folder) + "/");
				//File directory = new File(mappings_path);
				String filenames[] = directory.list();
				

				for(int i=0; i<filenames.length; i++){
					//if (!filenames[i].contains("oaei2012_FMA2SNMD_repaired_UMLS_mappings_alcomo.rdf"))
					//if (!filenames[i].contains("oaei2012_FMA2NCI_repaired_UMLS_mappings_alcomo.rdf"))
					if (!filenames[i].contains("refalign.rdf"))	
						continue;
					
					mappings_file = filenames[i].split("\\.")[0];
					
					gold_rdf = irirootpath_mappings + convert2ThreeDigitStrNumber(folder) + "/" + filenames[i];	
					gold_owl = irirootpath_mappings + convert2ThreeDigitStrNumber(folder) + "/" + mappings_file + ".owl";
					
					gold_txt = mappings_path + convert2ThreeDigitStrNumber(folder) + "/" + mappings_file + ".txt";
					//gold_rdf = irirootpath_mappings + filenames[i];	
					//gold_owl = irirootpath_mappings + mappings_file + ".owl";
					//gold_txt = mappings_path + mappings_file + ".txt";
				
					new FromRDFAlign2OWL(onto1, onto2, gold_rdf, gold_owl, gold_txt, true); //true for instance matching track
				}
				
				}//end for 4 instance
				*/
			}
		}
		catch (Exception e){
			e.printStackTrace();
		}

	}
	
	
	
	public static OWLOntology loadOntology(String uri) throws Exception{		
		return loadOntology(URI.create(uri));
	}
	
	public static OWLOntology loadOntology(URI uri) throws Exception{
		OWLOntologyManager ontologyManager=OWLManager.createOWLOntologyManager();
		return ontologyManager.loadOntology(uri);
		
	}
	
	
	
	//Ontology 1
	public void loadOntology1(String uri) throws Exception{		
		loadOntology1(URI.create(uri));
	}
	
	public void loadOntology1(URI uri) throws Exception{
		ontology1Manager=OWLManager.createOWLOntologyManager();
		ontology1 = ontology1Manager.loadOntology(uri);
		
	}
	
	
	//Ontology 2
	public void loadOntology2(String uri) throws Exception{		
		loadOntology2(URI.create(uri));
	}
	
	public void loadOntology2(URI uri) throws Exception{
		ontology2Manager=OWLManager.createOWLOntologyManager();
		ontology2 = ontology2Manager.loadOntology(uri);
	
	}
	
	

	//Gold Standard in xml
	public void loadGoldStandard(String uri) throws Exception{		
		loadGoldStandard(URI.create(uri));
	}
	
	public void loadGoldStandard(URI uri) throws Exception{
		goldStandardManager=OWLManager.createOWLOntologyManager();
		goldStandard = goldStandardManager.loadOntology(uri);
	
	}
	
	
	
	//Gold Standard out owl
//	Union Ontology
	public  void createGoldStandardOut(String uriStr, String phisycalUriStr) throws Exception{
		createGoldStandardOut(URI.create(uriStr), URI.create(phisycalUriStr));
	}
	
	public void createGoldStandardOut(URI uriLogic, URI uriPhis) throws Exception{
		
		
		
		
		
		
		
		
		
		//
		
		
		
		
		
		
	}
	
	
}
