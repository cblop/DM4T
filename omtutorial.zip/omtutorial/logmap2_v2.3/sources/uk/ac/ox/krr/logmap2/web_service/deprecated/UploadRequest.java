/*******************************************************************************
 * Copyright 2012 by the Department of Computer Science (University of Oxford)
 * 
 *    This file is part of LogMap.
 * 
 *    LogMap is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU Lesser General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 * 
 *    LogMap is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Lesser General Public License for more details.
 * 
 *    You should have received a copy of the GNU Lesser General Public License
 *    along with LogMap.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/
package uk.ac.ox.krr.logmap2.web_service.deprecated;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.Servlet;   
import javax.servlet.http.HttpServlet;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * 
 * Code adapted from Alexey Kakunin (Ajax Based File-Upload for Java)
 * @deprecated No used
 * 
 *
 */
public class UploadRequest extends HttpServlet implements Servlet {
	
	/**
	 * 
	 * Code adapted from Alexey Kakunin (Ajax Based File-Upload for Java)
	 * @deprecated No used
	 * 
	 *
	 */
    public UploadRequest() {
        super();
    }      
    /**
     * 
     * Code adapted from Alexey Kakunin (Ajax Based File-Upload for Java)
     * @deprecated No used
     * 
     *
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
                   
        HttpSession session = null;
        UploadListener listener = null;
        long contentLength = 0;
                   
        if ( ((session = request.getSession()) == null) ||
             ((listener = (UploadListener)session.getAttribute("LISTENER")) == null) ||                   
             ((contentLength = listener.getContentLength())<1)) {
            out.write("");
            out.close();
            return;                         
        }
                  
        response.setContentType("text/html");
        long percentComplite = ((100*listener.getBytesRead()) / contentLength);        
        out.print(percentComplite);
        out.close();           
    }
    
    
    
    /**
     * 
     * Code adapted from Alexey Kakunin (Ajax Based File-Upload for Java)
     * @deprecated No used
     * 
     *
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
       
        // create file upload factory and upload servlet
        FileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);
       
        // set file upload progress listener
        UploadListener listener = new UploadListener();
        HttpSession session = request.getSession();
        session.setAttribute("LISTENER", listener);
        // upload servlet allows to set upload listener
        upload.setProgressListener(listener);
               
        List items = null;
        FileItem fileItem = null;
        String filename = null;
        try {
            // iterate over all uploaded files
            items = upload.parseRequest(request);
            for (Iterator i = items.iterator(); i.hasNext();) {
                fileItem = (FileItem) i.next();
                if (!fileItem.isFormField()) {
                    if(fileItem.getSize()>0) {
                        // code that handle uploaded fileItem
                        // don't forget to delete uploaded files after you done with them! Use fileItem.delete();
                    	fileItem.getInputStream();
                    	PrintWriter out = response.getWriter();
                    	out.println("lalalalalal");
                    	fileItem.delete();
                    }
                }
            }
            // indicate that the upload was successfull
            response.getWriter().write("upload successful");
        } catch (FileUploadException e) {
            response.getWriter().write(e.getMessage());
        } catch (Exception e) {
            response.getWriter().write(e.getMessage());
        } finally {       
            session.removeAttribute("LISTENER");
        }       
    }

}
