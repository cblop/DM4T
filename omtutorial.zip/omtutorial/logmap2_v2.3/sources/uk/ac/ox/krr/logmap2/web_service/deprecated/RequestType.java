/*******************************************************************************
 * Copyright 2012 by the Department of Computer Science (University of Oxford)
 * 
 *    This file is part of LogMap.
 * 
 *    LogMap is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU Lesser General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 * 
 *    LogMap is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Lesser General Public License for more details.
 * 
 *    You should have received a copy of the GNU Lesser General Public License
 *    along with LogMap.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/
package uk.ac.ox.krr.logmap2.web_service.deprecated;
import java.io.*;   
import javax.servlet.*;   
import javax.servlet.http.*;   
    

public class RequestType extends HttpServlet {   
     
   
	public void doGet(HttpServletRequest req, HttpServletResponse rsp)   
                    throws ServletException, IOException {   
        rsp.setContentType("text/html");   
       PrintWriter out = rsp.getWriter();   
    
       out.println("<html>");   
       out.println("<head><title> Request Type: GET </title></head>");   
       out.println("<body>");   
       out.println("<p>This page is the result of a GET request.</p>");
       out.println("</body></html>");   
     }   
      
     public void doPost(HttpServletRequest req, HttpServletResponse rsp)   
                   throws ServletException, IOException {   
       rsp.setContentType("text/html");   
       PrintWriter out = rsp.getWriter();   
    
       
       String action = req.getParameter("action");
       String item = req.getParameter("item");
       
       //out.println("<html>");   
       //out.println("<head><title> Request Type: POST </title></head>");   
       //out.println("<body>");   
       out.println("<p>This page is the result of a POST request. Action: " + action + ", item: " +  item + ".</p>");   
       //out.println("</body></html>");   
       
       
       //CALL LOGMAP and SEND STATUS
                   
                  
     
     }  
    
    
}  
