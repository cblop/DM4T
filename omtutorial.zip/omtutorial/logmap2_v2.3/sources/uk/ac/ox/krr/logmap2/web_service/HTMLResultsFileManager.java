/*******************************************************************************
 * Copyright 2012 by the Department of Computer Science (University of Oxford)
 * 
 *    This file is part of LogMap.
 * 
 *    LogMap is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU Lesser General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 * 
 *    LogMap is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Lesser General Public License for more details.
 * 
 *    You should have received a copy of the GNU Lesser General Public License
 *    along with LogMap.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/
package uk.ac.ox.krr.logmap2.web_service;

import java.io.File;

import java.util.List;
import java.util.ArrayList;


import uk.ac.ox.krr.logmap2.io.ReadFile;
import uk.ac.ox.krr.logmap2.io.WriteFile;

/**
 * This class will manage the creation and update of the output file
 * @author Ernesto
 *
 */
public class HTMLResultsFileManager {

	private String file_output;
	
	private String uri_output;
	
	private WriteFile writer;
	
	private String date4folder;
	private String date2show;
	private String base_path;
	private String base_uri;
	
	private String day;
	private String month;
	private String year;
	private String hour;
	private String minute;
	private String second;
	private String milisecond;
	
	private String name;
	private String version;
	
	private String relative_output_path;
	
	private String uri1;
	private String uri2;
	
	private String integratedOntologyIRIStr="";
	private String integratedOntologyModulesIRIStr="";
	
	
	public HTMLResultsFileManager duplicate() {
		return new HTMLResultsFileManager(this.file_output, this.uri_output, this.relative_output_path);
	}
	
	
	//To clone class
	public HTMLResultsFileManager(
			String T_file_output,
			String T_uri_output,
			String T_relative_output_path
			){
		
		
		this.file_output=T_file_output;//
		this.uri_output=T_uri_output;//
		this.relative_output_path=T_relative_output_path;//
		
		
		
		
	}
	
	
	
	
	public HTMLResultsFileManager(String base_path, String base_uri, String name, String version, String uri1, String uri2){
		
		
		day = DateManager.getCurrentDay();
		month = DateManager.getCurrentMonth();
		year = DateManager.getCurrentYear();
		
		hour = DateManager.getCurrentHour();
		minute = DateManager.getCurrentMinute();
		second = DateManager.getCurrentSecond();
		milisecond = DateManager.getCurrentMilisecond();
		
		this.name=name;
		this.version=version;
		
		this.uri1=uri1;
		this.uri2=uri2;
		
		this.date4folder = day + "_" + month + "_" + year  + "__" + hour  + "_" + minute  + "_" + second  + "_" + milisecond;
		this.date2show = day + "/" + month + "/" + year;
		this.base_path =  base_path;
		this.base_uri=base_uri;
		
		createHTMLFile();
	}
	
	
	public String getHTMLResultsFile(){
		return file_output;
	}
	
	public String getHTMLResultsURI(){
		return uri_output;
	}
	
	
	public String getRelativeOutputPath(){
		return relative_output_path;
	}
	
	
	public String getIntegratedOntologyIRIStr(){
		return integratedOntologyIRIStr;
	}
	
	public String getIntegratedOntologyModulesIRIStr(){
		return integratedOntologyModulesIRIStr;
	}
	
	
	public void setIntegratedOntologyIRIStr(String IRIStr){
		integratedOntologyIRIStr=IRIStr;
	}
	
	public void setIntegratedOntologyModulesIRIStr(String IRIStr){
		integratedOntologyModulesIRIStr=IRIStr;
	}
	
	
	
	
	
	
	
	private void createHTMLFile(){
		
		relative_output_path = "/matching_" 
				+ date4folder;
		
		
		//Create output folder
		String output_folder = base_path + relative_output_path;
		File f = new File(output_folder);
		f.mkdir();
		
		
		//Create file
		file_output = output_folder + "/index.html";
		
		writer = new WriteFile(file_output);
		
		writeHeadersHTMLFile();
		
		writeBodyHTMLFile();
		
		writeCloseHTMLFile();
		
		
		writer.closeBuffer();
	       
		
		//Link to file
		uri_output = base_uri + "/output" + relative_output_path + "/index.html";
		
	}
	
	
	private void writeHeadersHTMLFile(){
		
		writer.writeLine("<html>");
		writer.writeLine("<head>");
		writer.writeLine("<title>LogMap Web Access</title>");
		writer.writeLine("<link rel=\"shortcut icon\" href=\""+ base_uri +"/favicon.ico\" />");
		writer.writeLine("</head>");
		
		writer.writeLine("<body>");

		//writer.writeLine("<a href=\""+base_uri+"\" target=\"blank\"><img src=\""+ base_uri +"/LM_logo.jpg\" height=\"50\" border=\"0\"></a>");
		writer.writeLine("<a href=\"http://www.cs.ox.ac.uk/isg/tools/LogMap/\" target=\"blank\"><img src=\""+ base_uri +"/LM_logo.jpg\" height=\"50\" border=\"0\"></a>");
		writer.writeLine("<br> <br>");
	}
	
	private void writeBodyHTMLFile(){
		
		writer.writeLine("<p><input type=\"button\" value=\"Go to request form\" onClick=\"window.location.href='" + base_uri + "'\"></p>");
		
		writer.writeLine("<fieldset>");
		writer.writeLine("<p><b>Progress of the matching task on " + date2show + " by " + name + " using " + version + ":</b>  <input type=\"button\" value=\"Refresh\" onClick=\"window.location.reload()\"></p>");
		writer.writeLine("<ul>");
		writer.writeLine("<li>" + hour + ":" + minute + ":" + second + ": LogMap is processing the request." + "</li>");
		writer.writeLine("<ul>");
		//writer.writeLine("<li><u>Ontology 1</u>: " + uri1 + "</li>");
		//writer.writeLine("<li><u>Ontology 2</u>: " + uri2 + "</li>");
		writer.writeLine("<li><b>Ontology 1:</b> " + "<a href=\""+uri1 +"\" target=\"_blank\">" + uri1 +  "</a></li>");
		writer.writeLine("<li><b>Ontology 2:</b> " + "<a href=\""+uri2 +"\" target=\"_blank\">" + uri2 +  "</a></li>");

		writer.writeLine("</ul>");
	
	}
	
	private void writeCloseHTMLFile(){
		
		writer.writeLine("</ul></fieldset></body></html>");
		
	}
	
	public void updateProgress(String progressInfo){
		
		hour = DateManager.getCurrentHour();
		minute = DateManager.getCurrentMinute();
		second = DateManager.getCurrentSecond();
		
		String newline = "<li>" + hour + ":" + minute + ":" + second + ": " + progressInfo + "</li>";
		
		
		try{
			//READ FILE
			List<String> file_lines = new ArrayList<String>();
			ReadFile reader = new ReadFile(file_output);
			String line;
			while ((line = reader.readLine()) != null){
				file_lines.add(line);
			}
			reader.closeBuffer();
			
			
			
			//Rewrite file
			//-----
			writer = new WriteFile(file_output);//new one
			
			//Modify
			for (int i=0; i<file_lines.size()-1; i++){
				writer.writeLine(file_lines.get(i));
			}
			
			writer.writeLine(newline);
			
			writer.writeLine(file_lines.get(file_lines.size()-1));//last line
			
			//close file
			writer.closeBuffer();
		}
		catch(Exception e){
			//System.err.println("");
		}
	}
	
	
}
