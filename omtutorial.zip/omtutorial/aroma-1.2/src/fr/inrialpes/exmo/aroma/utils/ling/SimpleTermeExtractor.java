/**
 *   Copyright 2007, 2008 Jérôme DAVID, Université de Nantes, INRIA, Université Pierre Mendès France
 *   
 *   SimpleTermeExtractor.java is part of AROMA.
 *
 *   AROMA is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   AROMA is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with AROMA; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
package fr.inrialpes.exmo.aroma.utils.ling;

import java.util.HashSet;
import java.util.Set;

public class SimpleTermeExtractor implements TermExtractor {
    private static String TERM_TYPE = "unary";

    public SimpleTermeExtractor() {

    }

    public Set<String> getTerms(String lemmatisedText) {
	Set<String> v = new HashSet<String>();
	String[] words = lemmatisedText.split(" ");
	// System.err.println(words.length);
	for (int i = 0; i < words.length; i++) {
	    if (words[i].matches(".*/NN.?/.*/1")) {
		v.add(words[i].split("/")[2]);
		// System.err.println(words[i].split("/")[2]);
	    }
	}
	return v;
    }

    public Set<String> getTerms(String text, String language) {
	return getTerms(text);
    }
    
    public String getTermType() {
	return TERM_TYPE;
    }

    /* (non-Javadoc)
     * @see fr.inrialpes.exmo.aroma.utils.ling.TermExtractor#free()
     */
    @Override
    public void free() {
	// TODO Auto-generated method stub
	
    }
}
